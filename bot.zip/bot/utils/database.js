
const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, '..', 'data.json');

// Initialize database if it doesn't exist
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({ users: {}, transactions: [] }, null, 2));
}

function readDatabase() {
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}

function writeDatabase(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

function getUserPoints(userId) {
  const data = readDatabase();
  return data.users[userId]?.points || 0;
}

function getUserHistory(userId) {
  const data = readDatabase();
  return data.users[userId]?.history || [];
}

function updatePoints(userId, pointsToAdd, reason, moderatorId) {
  try {
    const data = readDatabase();
    
    // Initialize user data if it doesn't exist
    if (!data.users[userId]) {
      data.users[userId] = {
        points: 0,
        history: []
      };
    }
    
    // Update points
    data.users[userId].points += pointsToAdd;
    
    // Add to history
    const transaction = {
      userId,
      moderatorId,
      points: pointsToAdd,
      reason,
      timestamp: Date.now()
    };
    
    data.users[userId].history.push(transaction);
    data.transactions.push(transaction);
    
    // Save changes
    writeDatabase(data);
    return true;
  } catch (error) {
    console.error('Error updating points:', error);
    return false;
  }
}

module.exports = {
  getUserPoints,
  getUserHistory,
  readDatabase,
  writeDatabase,
  updatePoints
};
