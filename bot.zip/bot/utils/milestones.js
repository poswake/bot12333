
// Define milestone levels and their requirements
const milestones = [
  {
    name: 'Rookie',
    emoji: '🌱',
    threshold: 0,
    description: 'Just getting started'
  },
  {
    name: 'Enforcer',
    emoji: '👮',
    threshold: 60,
    description: 'Achieved Enforcer rank'
  },
  {
    name: 'Operator',
    emoji: '⭐',
    threshold: 100,
    description: 'Achieved Operator rank'
  },
  {
    name: 'Sergeant',
    emoji: '🎖️',
    threshold: 200,
    description: 'Achieved Sergeant rank'
  }
];

// Get all milestones
function getAllMilestones() {
  return milestones.map((milestone, index) => ({
    ...milestone,
    next: milestones[index + 1]
  }));
}

// Get milestone for specific points
function getMilestoneForPoints(points) {
  for (let i = milestones.length - 1; i >= 0; i--) {
    if (points >= milestones[i].threshold) {
      return {
        current: milestones[i],
        next: milestones[i + 1]
      };
    }
  }
  return {
    current: milestones[0],
    next: milestones[1]
  };
}

// Generate progress bar
function generateProgressBar(points) {
  const { current, next } = getMilestoneForPoints(points);
  const start = current.threshold;
  const end = next ? next.threshold : current.threshold;
  
  // Calculate percentage
  const totalRange = end - start;
  const currentProgress = points - start;
  const percentage = next ? Math.min(Math.floor((currentProgress / totalRange) * 100), 100) : 100;
  
  // Generate bar
  const barLength = 20;
  const filledLength = Math.floor((percentage / 100) * barLength);
  const bar = '█'.repeat(filledLength) + '░'.repeat(barLength - filledLength);
  
  return {
    bar,
    percentage,
    current,
    next,
    pointsToNext: next ? next.threshold - points : 0
  };
}

// Create animated progress bar frames
function createAnimatedProgressBar(points) {
  const { percentage } = generateProgressBar(points);
  const frames = [];
  const barLength = 20;
  const filledLength = Math.floor((percentage / 100) * barLength);
  
  // Create basic frame
  const baseFrame = '█'.repeat(filledLength) + '░'.repeat(barLength - filledLength);
  frames.push(baseFrame);
  
  // Create animated frames
  if (filledLength > 0) {
    for (let i = 0; i < filledLength; i++) {
      const animFrame = '█'.repeat(i) + '▒' + '█'.repeat(filledLength - i - 1) + '░'.repeat(barLength - filledLength);
      frames.push(animFrame);
    }
  }
  
  return frames;
}

module.exports = {
  getAllMilestones,
  getMilestoneForPoints,
  generateProgressBar,
  createAnimatedProgressBar
};
