const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../utils/database');
const config = require('../config');
const fs = require('fs');
const path = require('path');

// Define the event types as choices for the command
const EVENT_TYPES = [
  { name: 'Assault', value: 'Assault' },
  { name: 'Patrol Response', value: 'Patrol Response' },
  { name: 'Down with the Facility', value: 'Down with the Facility' },
  { name: 'Training', value: 'Training' }
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('schedule')
    .setDescription('Schedule an event')
    .addStringOption(option => 
      option.setName('event_type')
        .setDescription('Type of event')
        .setRequired(true)
        .addChoices(...EVENT_TYPES))
    .addStringOption(option => 
      option.setName('date')
        .setDescription('Date of the event (MM/DD/YY)')
        .setRequired(true))
    .addStringOption(option => 
      option.setName('time')
        .setDescription('Time of the event (HH:MM AM/PM) in 12-hour format')
        .setRequired(true))
    .addStringOption(option => 
      option.setName('notes')
        .setDescription('Additional notes about the event')
        .setRequired(false)),
  
  async execute(interaction) {
    // Check if user has the agent role or higher
    const agentRoleId = config.AGENT_ROLE_ID;
    const guildMember = interaction.member;
    
    // Check if user has the specific role or any higher role
    const hasRequiredPermission = guildMember.roles.cache.some(role => {
      return role.id === agentRoleId || (role.position > guildMember.guild.roles.cache.get(agentRoleId)?.position);
    });
    
    if (!hasRequiredPermission) {
      return interaction.reply({
        content: `You need the <@&${agentRoleId}> role or higher to schedule events.`,
        ephemeral: true
      });
    }
    
    // Get options
    const eventType = interaction.options.getString('event_type');
    const dateString = interaction.options.getString('date');
    const timeString = interaction.options.getString('time');
    const notes = interaction.options.getString('notes') || 'No additional notes.';
    
    // Validate date format (MM/DD/YY)
    const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{2})$/;
    if (!datePattern.test(dateString)) {
      return interaction.reply({
        content: 'Please provide the date in MM/DD/YY format (e.g., 03/15/25).',
        ephemeral: true
      });
    }
    
    // Validate time format (HH:MM AM/PM)
    const timePattern = /^(0?[1-9]|1[0-2]):([0-5][0-9])(?:\s)?(AM|PM|am|pm)$/;
    const timeMatch = timeString.match(timePattern);
    
    if (!timeMatch) {
      return interaction.reply({
        content: 'Please provide the time in HH:MM AM/PM format (e.g., 5:30 PM).',
        ephemeral: true
      });
    }
    
    // Create a Date object from the date and time inputs in UTC
    const [month, day, year] = dateString.split('/');
    let [hours, minutes] = [parseInt(timeMatch[1]), parseInt(timeMatch[2])];
    const isPM = timeMatch[3].toUpperCase() === 'PM';
    
    // Convert to 24-hour format if PM
    if (isPM && hours < 12) {
      hours += 12;
    }
    // Convert 12 AM to 0 hours
    if (!isPM && hours === 12) {
      hours = 0;
    }
    
    // Create the Date object in UTC (using 2000 + year as YY format)
    const eventDate = new Date(Date.UTC(2000 + parseInt(year), parseInt(month) - 1, parseInt(day), hours, minutes));
    
    // Check if the date is valid
    if (isNaN(eventDate.getTime())) {
      return interaction.reply({
        content: 'The date and time provided is invalid. Please try again.',
        ephemeral: true
      });
    }
    
    // Format the date and time for display
    const formattedDateTime = `${dateString} at ${timeString}`;
    
    // Load existing schedule data or create new if doesn't exist
    const scheduleFilePath = path.join(__dirname, '..', 'schedule.json');
    let scheduleData = [];
    
    if (fs.existsSync(scheduleFilePath)) {
      try {
        const fileContent = fs.readFileSync(scheduleFilePath, 'utf8');
        scheduleData = JSON.parse(fileContent);
      } catch (error) {
        console.error('Error reading schedule file:', error);
      }
    }
    
    // Create new event
    const newEvent = {
      id: Date.now().toString(), // Use timestamp as unique ID
      type: eventType,
      date: dateString,
      time: timeString,
      timestamp: eventDate.getTime(), // Store Unix timestamp
      notes: notes,
      createdBy: interaction.user.id,
      createdAt: new Date().toISOString(),
      attendees: [] // Initialize with empty attendees list
    };
    
    // Add event to schedule
    scheduleData.push(newEvent);
    
    // Save schedule data
    try {
      fs.writeFileSync(scheduleFilePath, JSON.stringify(scheduleData, null, 2), 'utf8');
    } catch (error) {
      console.error('Error saving schedule:', error);
      return interaction.reply({
        content: 'There was an error saving the event. Please try again.',
        ephemeral: true
      });
    }
    
    // Create Discord timestamps for the event (shows in user's local time)
    // F = Full date and time format (e.g., "Monday, June 1, 2023 4:30 PM")
    // f = Short date and time format (e.g., "June 1, 2023 4:30 PM")
    // t = Short time format (e.g., "4:30 PM")
    // D = Full date format (e.g., "June 1, 2023")
    // R = Relative time format (e.g., "in 2 days")
    const timestamp = Math.floor(eventDate.getTime() / 1000);
    const fullTimestamp = `<t:${timestamp}:F>`;  // Full date and time
    const shortTimestamp = `<t:${timestamp}:f>`; // Short date and time 
    const timeOnlyTimestamp = `<t:${timestamp}:t>`; // Time only
    const dateOnlyTimestamp = `<t:${timestamp}:D>`; // Date only
    const relativeTimestamp = `<t:${timestamp}:R>`; // Relative time
    
    // Create an embed to display the scheduled event
    const embed = new EmbedBuilder()
      .setColor(getEventColor(eventType))
      .setTitle(`🗓️ New ${eventType} Scheduled`)
      .addFields(
        { name: 'Event Type', value: eventType, inline: true },
        { name: 'Date', value: dateOnlyTimestamp, inline: true },
        { name: 'Time', value: timeOnlyTimestamp, inline: true },
        { name: 'Full Date & Time', value: shortTimestamp, inline: false },
        { name: 'Time Until Event', value: relativeTimestamp, inline: false },
        { name: 'Scheduled By', value: `<@${interaction.user.id}>`, inline: false },
        { name: 'Notes', value: notes }
      )
      .setTimestamp()
      .setFooter({ text: `Event ID: ${newEvent.id}` });
    
    // Create the attendance button
    const attendButton = new ButtonBuilder()
      .setCustomId(`attend_${newEvent.id}`)
      .setLabel('I\'m Attending!')
      .setStyle(ButtonStyle.Success)
      .setEmoji('✅');
    
    // Add the button to an action row
    const row = new ActionRowBuilder().addComponents(attendButton);
    
    // Send confirmation with the button
    return interaction.reply({
      content: `Event has been scheduled successfully.`,
      embeds: [embed],
      components: [row]
    });
  }
};

// Get a color for the embed based on event type
function getEventColor(eventType) {
  switch (eventType) {
    case 'Assault':
      return '#FF0000'; // Red
    case 'Patrol Response':
      return '#0099FF'; // Blue
    case 'Down with the Facility':
      return '#FF9900'; // Orange
    case 'Training':
      return '#33CC33'; // Green
    default:
      return '#6E6E6E'; // Gray
  }
}