const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Display the points leaderboard')
    .addIntegerOption(option => 
      option.setName('limit')
        .setDescription('Number of users to show (default: 10)')
        .setMinValue(1)
        .setMaxValue(25)),
  
  async execute(interaction) {
    await interaction.deferReply();
    
    // Get the limit from options or set default to 10
    const limit = interaction.options.getInteger('limit') || 10;
    
    // Get all users from database
    const allUsers = db.getAllUsers();
    
    // Convert users object to array and sort by points (descending)
    const sortedUsers = Object.entries(allUsers)
      .map(([userId, userData]) => ({
        id: userId,
        points: userData.points
      }))
      .sort((a, b) => b.points - a.points)
      .slice(0, limit);
    
    if (sortedUsers.length === 0) {
      return interaction.editReply('No users have any points yet!');
    }
    
    // Build the leaderboard embed
    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('Points Leaderboard')
      .setDescription(`Top ${Math.min(limit, sortedUsers.length)} users`)
      .setTimestamp();
    
    // Fetch user information for each user ID and add to the embed
    let leaderboardText = '';
    
    // Process each user in the leaderboard
    for (let i = 0; i < sortedUsers.length; i++) {
      const user = sortedUsers[i];
      // Try to fetch user info from Discord
      try {
        const discordUser = await interaction.client.users.fetch(user.id);
        leaderboardText += `**${i + 1}.** ${discordUser.username}: **${user.points}** points\n`;
      } catch (error) {
        // If we can't fetch the user (e.g., they left the server)
        leaderboardText += `**${i + 1}.** Unknown User (${user.id}): **${user.points}** points\n`;
      }
    }
    
    embed.setDescription(leaderboardText);
    
    // Add a footer explaining how to check your own points
    embed.setFooter({ 
      text: 'Use /mypoints to check your own points and recent history'
    });
    
    return interaction.editReply({ embeds: [embed] });
  }
};