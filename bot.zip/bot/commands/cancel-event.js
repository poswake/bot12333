const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cancel-event')
    .setDescription('Cancel a scheduled event')
    .addStringOption(option => 
      option.setName('event_id')
        .setDescription('ID of the event to cancel')
        .setRequired(true)),
  
  async execute(interaction) {
    // Check if user has the agent role or higher
    const agentRoleId = config.AGENT_ROLE_ID;
    const guildMember = interaction.member;
    
    // Check if user has the specific role or any higher role
    const hasRequiredPermission = guildMember.roles.cache.some(role => {
      return role.id === agentRoleId || (role.position > guildMember.guild.roles.cache.get(agentRoleId)?.position);
    });
    
    if (!hasRequiredPermission) {
      return interaction.reply({
        content: `You need the <@&${agentRoleId}> role or higher to cancel events.`,
        ephemeral: true
      });
    }
    
    const eventId = interaction.options.getString('event_id');
    
    // Load schedule data
    const scheduleFilePath = path.join(__dirname, '..', 'schedule.json');
    let scheduleData = [];
    
    if (!fs.existsSync(scheduleFilePath)) {
      return interaction.reply({
        content: 'No events are currently scheduled.',
        ephemeral: true
      });
    }
    
    try {
      const fileContent = fs.readFileSync(scheduleFilePath, 'utf8');
      scheduleData = JSON.parse(fileContent);
    } catch (error) {
      console.error('Error reading schedule file:', error);
      return interaction.reply({
        content: 'There was an error reading the schedule data.',
        ephemeral: true
      });
    }
    
    // Find the event to cancel
    const eventIndex = scheduleData.findIndex(event => event.id === eventId);
    
    if (eventIndex === -1) {
      return interaction.reply({
        content: `No event found with ID ${eventId}. Use /events to see all scheduled events.`,
        ephemeral: true
      });
    }
    
    // Store event details before removing
    const canceledEvent = scheduleData[eventIndex];
    
    // Remove the event
    scheduleData.splice(eventIndex, 1);
    
    // Save updated schedule data
    try {
      fs.writeFileSync(scheduleFilePath, JSON.stringify(scheduleData, null, 2), 'utf8');
    } catch (error) {
      console.error('Error saving schedule:', error);
      return interaction.reply({
        content: 'There was an error canceling the event. Please try again.',
        ephemeral: true
      });
    }
    
    // Create formatted timestamp displays
    let dateDisplay = canceledEvent.date;
    let timeDisplay = canceledEvent.time || 'No time specified';
    let fullTimeDisplay = `${canceledEvent.date}${canceledEvent.time ? ' at ' + canceledEvent.time : ''}`;
    
    // If we have timestamp data, use Discord timestamps
    if (canceledEvent.timestamp) {
      const unix = Math.floor(canceledEvent.timestamp / 1000);
      dateDisplay = `<t:${unix}:D>`; // Date only format
      timeDisplay = `<t:${unix}:t>`; // Time only format
      fullTimeDisplay = `<t:${unix}:f>`; // Short date and time format
    }
    
    // Create an embed to confirm the cancellation
    const embed = new EmbedBuilder()
      .setColor('#FF3333')
      .setTitle('🚫 Event Canceled')
      .addFields(
        { name: 'Event Type', value: canceledEvent.type, inline: true },
        { name: 'Date', value: dateDisplay, inline: true },
        { name: 'Time', value: timeDisplay, inline: true },
        { name: 'Full Date & Time', value: fullTimeDisplay, inline: false },
        { name: 'Canceled By', value: `<@${interaction.user.id}>`, inline: false },
        { name: 'Notes', value: canceledEvent.notes }
      )
      .setTimestamp();
    
    // Check if there are attendees to notify
    const hasAttendees = canceledEvent.attendees && canceledEvent.attendees.length > 0;
    
    // Send cancellation notification to the attendance channel if there were attendees
    if (hasAttendees) {
      try {
        // Get the guild from the interaction
        const guild = interaction.guild;
        
        // Look for the attendance channel
        let attendanceChannel;
        const channelId = config.ATTENDANCE_CHANNEL_ID;
        
        // Try to get the channel by ID first
        if (channelId.match(/^\d+$/)) {
          attendanceChannel = await guild.channels.fetch(channelId).catch(() => null);
        }
        
        // If that fails, try to find by name
        if (!attendanceChannel) {
          attendanceChannel = guild.channels.cache.find(channel => 
            channel.name === channelId && channel.type === 0 // Type 0 = text channel
          );
        }
        
        // If we found a channel, send the notification
        if (attendanceChannel) {
          // Create the notification message
          const attendeeCount = canceledEvent.attendees.length;
          const attendeeMentions = canceledEvent.attendees.map(id => `<@${id}>`).join(', ');
          
          // Send notification to the channel
          await attendanceChannel.send({
            content: `🚨 **ATTENTION:** The **${canceledEvent.type}** event scheduled for ${fullTimeDisplay} has been canceled by <@${interaction.user.id}>.\n\n**To the ${attendeeCount} attendee(s):** ${attendeeMentions}`,
            embeds: [embed]
          });
        }
      } catch (error) {
        console.error('Error sending cancellation notification:', error);
        // We don't want the notification failure to affect the command response
      }
    }
    
    // Send confirmation
    return interaction.reply({
      content: `Event has been canceled successfully.${hasAttendees ? ` Notification sent to ${canceledEvent.attendees.length} attendee(s).` : ''}`,
      embeds: [embed]
    });
  }
};