const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('myattendance')
    .setDescription('View the events you are attending'),
  
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    // Get user ID
    const userId = interaction.user.id;
    
    // Load schedule data
    const scheduleFilePath = path.join(__dirname, '..', 'schedule.json');
    let scheduleData = [];
    
    if (fs.existsSync(scheduleFilePath)) {
      try {
        const fileContent = fs.readFileSync(scheduleFilePath, 'utf8');
        scheduleData = JSON.parse(fileContent);
      } catch (error) {
        console.error('Error reading schedule file:', error);
        return interaction.editReply('There was an error reading the schedule data.');
      }
    } else {
      return interaction.editReply('No events are currently scheduled.');
    }
    
    // Filter to events the user is attending
    const userEvents = scheduleData.filter(event => 
      event.attendees && event.attendees.includes(userId)
    );
    
    // If not attending any events
    if (userEvents.length === 0) {
      return interaction.editReply('You are not currently attending any scheduled events.');
    }
    
    // Ensure we have timestamp data for sorting and display
    userEvents.forEach(event => {
      if (event.timestamp) {
        event.dateObj = new Date(event.timestamp);
      } else {
        // Handle older event format without timestamp
        const [month, day, year] = event.date.split('/');
        
        if (event.time) {
          // Parse HH:MM AM/PM format
          const timePattern = /^(0?[1-9]|1[0-2]):([0-5][0-9])(?:\s)?(AM|PM|am|pm)$/;
          const timeMatch = event.time.match(timePattern);
          
          if (timeMatch) {
            let [hours, minutes] = [parseInt(timeMatch[1]), parseInt(timeMatch[2])];
            const isPM = timeMatch[3].toUpperCase() === 'PM';
            
            // Convert to 24-hour format if PM
            if (isPM && hours < 12) hours += 12;
            if (!isPM && hours === 12) hours = 0;
            
            event.dateObj = new Date(2000 + parseInt(year), parseInt(month) - 1, parseInt(day), hours, minutes);
          } else {
            event.dateObj = new Date(2000 + parseInt(year), parseInt(month) - 1, parseInt(day));
          }
        } else {
          event.dateObj = new Date(2000 + parseInt(year), parseInt(month) - 1, parseInt(day));
        }
        
        // Store the timestamp for future use
        event.timestamp = event.dateObj.getTime();
      }
    });
    
    // Sort events by date (closest first)
    userEvents.sort((a, b) => a.dateObj - b.dateObj);
    
    // Remove past events (older than current date)
    const currentDate = new Date();
    const upcomingEvents = userEvents.filter(event => event.dateObj >= currentDate);
    
    // Create embed
    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('📅 My Upcoming Events')
      .setDescription(`You are currently attending ${upcomingEvents.length} upcoming event(s)`)
      .setTimestamp()
      .setFooter({ text: `Requested by ${interaction.user.username}` });
    
    // Add events to embed
    if (upcomingEvents.length === 0) {
      embed.setDescription('You are not attending any upcoming events. All events you have signed up for have already passed.');
    } else {
      let eventsText = '';
      
      upcomingEvents.forEach(event => {
        // Add emoji based on event type
        let emoji = '🔷';
        if (event.type === 'Assault') emoji = '⚔️';
        if (event.type === 'Patrol Response') emoji = '🚨';
        if (event.type === 'Down with the Facility') emoji = '🏢';
        if (event.type === 'Training') emoji = '🎓';
        
        // Create Discord timestamps that will show in user's local time
        const unix = Math.floor(event.timestamp / 1000);
        const dateOnlyTimestamp = `<t:${unix}:D>`; // Date only
        const timeOnlyTimestamp = `<t:${unix}:t>`; // Time only
        const relativeTime = `<t:${unix}:R>`;      // Relative time
        
        eventsText += `${emoji} **${event.type}**\n`;
        eventsText += `› Date: ${dateOnlyTimestamp}\n`;
        eventsText += `› Time: ${timeOnlyTimestamp}\n`;
        eventsText += `› ${relativeTime}\n`;
        eventsText += `› Notes: ${event.notes}\n`;
        eventsText += `› ID: ${event.id}\n\n`;
      });
      
      embed.addFields({ name: 'Events You Are Attending', value: eventsText });
    }
    
    // Send response (ephemeral - only visible to the user)
    return interaction.editReply({ embeds: [embed] });
  }
};