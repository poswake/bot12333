const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../utils/database');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('points')
    .setDescription('Manage points for users')
    .addSubcommand(subcommand =>
      subcommand
        .setName('add')
        .setDescription('Add points to a user')
        .addUserOption(option => 
          option.setName('user')
            .setDescription('The user to add points to')
            .setRequired(true))
        .addIntegerOption(option => 
          option.setName('amount')
            .setDescription('Number of points to add')
            .setRequired(true)
            .setMinValue(1))
        .addStringOption(option => 
          option.setName('reason')
            .setDescription('Reason for adding points')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('subtract')
        .setDescription('Subtract points from a user')
        .addUserOption(option => 
          option.setName('user')
            .setDescription('The user to subtract points from')
            .setRequired(true))
        .addIntegerOption(option => 
          option.setName('amount')
            .setDescription('Number of points to subtract')
            .setRequired(true)
            .setMinValue(1))
        .addStringOption(option => 
          option.setName('reason')
            .setDescription('Reason for subtracting points')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('check')
        .setDescription('Check a user\'s points')
        .addUserOption(option => 
          option.setName('user')
            .setDescription('The user to check points for')
            .setRequired(true))),
  
  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    
    // For add/subtract, check if user has the required agent role or higher
    if (subcommand === 'add' || subcommand === 'subtract') {
      // Get the agent role from config
      const agentRoleId = config.AGENT_ROLE_ID;
      
      // Check if user has the specific role or any higher role
      const guildMember = interaction.member;
      const hasRequiredPermission = guildMember.roles.cache.some(role => {
        return role.id === agentRoleId || (role.position > guildMember.guild.roles.cache.get(agentRoleId)?.position);
      });
      
      if (!hasRequiredPermission) {
        return interaction.reply({
          content: `You need the <@&${agentRoleId}> role or higher to ${subcommand} points.`,
          ephemeral: true
        });
      }
    }
    
    // Check command - accessible by anyone for themselves, but only agents or higher for others
    if (subcommand === 'check') {
      const user = interaction.options.getUser('user');
      
      // If checking someone else's points, verify permissions
      if (user.id !== interaction.user.id) {
        const agentRoleId = config.AGENT_ROLE_ID;
        const guildMember = interaction.member;
        
        // Check if user has the specific role or any higher role
        const hasRequiredPermission = guildMember.roles.cache.some(role => {
          return role.id === agentRoleId || (role.position > guildMember.guild.roles.cache.get(agentRoleId)?.position);
        });
        
        if (!hasRequiredPermission) {
          return interaction.reply({
            content: `You need the <@&${agentRoleId}> role or higher to check other users' points. Use /mypoints to check your own points.`,
            ephemeral: true
          });
        }
      }
      
      const points = db.getUserPoints(user.id);
      
      const embed = new EmbedBuilder()
        .setColor('#0099ff')
        .setTitle('Points Check')
        .addFields(
          { name: 'User', value: `<@${user.id}>`, inline: true },
          { name: 'Total Points', value: points.toString(), inline: true }
        )
        .setTimestamp();
      
      return interaction.reply({ embeds: [embed] });
    }
    
    // Add or subtract points (only for agents with the right role)
    const user = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    const reason = interaction.options.getString('reason');
    
    // Calculate points to apply (positive for add, negative for subtract)
    const pointsToApply = subcommand === 'add' ? amount : -amount;
    
    // Update the database
    const success = db.updatePoints(
      user.id,
      pointsToApply,
      reason,
      interaction.user.id
    );
    
    if (!success) {
      return interaction.reply({ 
        content: 'There was an error updating the points.', 
        ephemeral: true 
      });
    }
    
    // Get the updated total
    const totalPoints = db.getUserPoints(user.id);
    
    // Create an embed for the response
    const embed = new EmbedBuilder()
      .setColor(subcommand === 'add' ? '#00ff00' : '#ff0000')
      .setTitle(`Points ${subcommand === 'add' ? 'Added' : 'Subtracted'}`)
      .setDescription(`${subcommand === 'add' ? 'Added' : 'Subtracted'} ${amount} points ${subcommand === 'add' ? 'to' : 'from'} ${user.username}`)
      .addFields(
        { name: 'User', value: `<@${user.id}>`, inline: true },
        { name: 'Agent', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'New Total', value: totalPoints.toString(), inline: true },
        { name: 'Reason', value: reason }
      )
      .setTimestamp();
    
    // Send a DM to the user to inform them about the points change
    try {
      // Create a DM embed with similar info
      const dmEmbed = new EmbedBuilder()
        .setColor(subcommand === 'add' ? '#00ff00' : '#ff0000')
        .setTitle(`Points ${subcommand === 'add' ? 'Added' : 'Subtracted'}`)
        .setDescription(`Your points have been ${subcommand === 'add' ? 'increased by' : 'decreased by'} ${amount}`)
        .addFields(
          { name: 'Your New Total', value: totalPoints.toString(), inline: true },
          { name: 'Modified By', value: `${interaction.user.username}`, inline: true },
          { name: 'Reason', value: reason }
        )
        .setTimestamp();
      
      // Send the DM
      await user.send({ embeds: [dmEmbed] }).catch(error => {
        console.log(`Could not send DM to ${user.username}. They might have DMs closed.`);
        // We'll still continue even if the DM fails
      });
    } catch (error) {
      console.error(`Error sending DM to user ${user.username}:`, error);
      // We don't want to fail the whole command if just the DM fails
    }
    
    return interaction.reply({ embeds: [embed] });
  }
};
