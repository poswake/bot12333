const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../utils/database');
const milestones = require('../utils/milestones');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mypoints')
    .setDescription('Check your own points'),
  
  async execute(interaction) {
    // Get user and their points
    const userId = interaction.user.id;
    const points = db.getUserPoints(userId);
    
    // Get milestone information
    const progressInfo = milestones.generateProgressBar(points);
    const currentMilestone = progressInfo.current;
    const nextMilestone = progressInfo.next;
    
    // Create the initial progress bar and status
    const initialFrame = progressInfo.bar;
    
    // Create the animated frames for the progress bar
    const animatedFrames = milestones.createAnimatedProgressBar(points);
    
    // Create initial embed
    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle(`${currentMilestone.emoji} Your Points: ${points}`)
      .setTimestamp()
      .setFooter({ 
        text: `${interaction.user.username} | Progress will animate momentarily...`, 
        iconURL: interaction.user.displayAvatarURL() 
      });
    
    // Add milestone and progress information
    if (nextMilestone) {
      embed.setDescription(
        `Current Rank: **${currentMilestone.name}** ${currentMilestone.emoji}\n` +
        `Next Rank: **${nextMilestone.name}** ${nextMilestone.emoji}\n` +
        `Progress: \`${initialFrame}\` ${progressInfo.percentage}%\n` +
        `Points needed for next rank: **${progressInfo.pointsToNext}**`
      );
    } else {
      embed.setDescription(
        `Current Rank: **${currentMilestone.name}** ${currentMilestone.emoji}\n` +
        `Progress: \`${initialFrame}\` 100%\n` +
        `🎊 **Congratulations!** You've reached the maximum rank! 🎊`
      );
    }
    
    // Add top 3 transactions if they exist
    const history = db.getUserHistory(userId);
    
    if (history && history.length > 0) {
      // Sort by timestamp (newest first)
      const recentHistory = [...history]
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, 3);
      
      let recentText = '';
      
      for (const entry of recentHistory) {
        const pointsText = entry.points > 0 ? `+${entry.points}` : `${entry.points}`;
        const date = new Date(entry.timestamp).toLocaleString();
        recentText += `• ${date}: **${pointsText}** points - ${entry.reason}\n`;
      }
      
      embed.addFields({ 
        name: 'Recent Transactions', 
        value: recentText || 'No recent transactions' 
      });
    }
    
    // Add button to view all milestones
    const viewMilestonesButton = new ButtonBuilder()
      .setCustomId('view_milestones')
      .setLabel('View All Milestones')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('📊');
      
    const row = new ActionRowBuilder().addComponents(viewMilestonesButton);
    
    // Send the initial message
    const reply = await interaction.reply({ 
      embeds: [embed], 
      components: [row],
      ephemeral: true,
      fetchReply: true
    });
    
    // Animate the progress bar by editing the message
    // We'll only do a few frames to avoid rate limiting
    let currentFrameIndex = 0;
    
    // Create an animation interval (every 1.5 seconds to avoid rate limiting)
    const animationInterval = setInterval(async () => {
      // Move to the next frame
      currentFrameIndex = (currentFrameIndex + 1) % animatedFrames.length;
      const currentFrame = animatedFrames[currentFrameIndex];
      
      // Update the embed with the new frame
      const updatedEmbed = EmbedBuilder.from(embed);
      
      if (nextMilestone) {
        updatedEmbed.setDescription(
          `Current Rank: **${currentMilestone.name}** ${currentMilestone.emoji}\n` +
          `Next Rank: **${nextMilestone.name}** ${nextMilestone.emoji}\n` +
          `Progress: \`${currentFrame}\` ${progressInfo.percentage}%\n` +
          `Points needed for next rank: **${progressInfo.pointsToNext}**`
        );
      } else {
        updatedEmbed.setDescription(
          `Current Rank: **${currentMilestone.name}** ${currentMilestone.emoji}\n` +
          `Progress: \`${currentFrame}\` 100%\n` +
          `🎊 **Congratulations!** You've reached the maximum rank! 🎊`
        );
      }
      
      updatedEmbed.setFooter({ 
        text: `${interaction.user.username}`, 
        iconURL: interaction.user.displayAvatarURL() 
      });
      
      // Edit the message with the new frame
      try {
        await interaction.editReply({ 
          embeds: [updatedEmbed],
          components: [row]
        });
      } catch (error) {
        // Stop the animation if there's an error (e.g., message deleted or timed out)
        clearInterval(animationInterval);
        console.error('Error updating progress bar animation:', error);
      }
      
      // Only run the animation for a limited number of frames to avoid excessive API calls
      if (currentFrameIndex === animatedFrames.length - 1) {
        clearInterval(animationInterval);
      }
    }, 1500); // Update every 1.5 seconds
    
    // Automatically clear the interval after a maximum duration
    setTimeout(() => {
      clearInterval(animationInterval);
    }, 10000); // Stop after 10 seconds maximum
    
    return;
  }
};