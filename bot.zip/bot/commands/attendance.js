const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('attendance')
    .setDescription('View who is attending an event')
    .addStringOption(option =>
      option.setName('event_id')
        .setDescription('The ID of the event to check attendance for')
        .setRequired(true)),
  
  async execute(interaction) {
    await interaction.deferReply();
    
    // Get event ID
    const eventId = interaction.options.getString('event_id');
    
    // Load schedule data
    const scheduleFilePath = path.join(__dirname, '..', 'schedule.json');
    let scheduleData = [];
    
    if (fs.existsSync(scheduleFilePath)) {
      try {
        const fileContent = fs.readFileSync(scheduleFilePath, 'utf8');
        scheduleData = JSON.parse(fileContent);
      } catch (error) {
        console.error('Error reading schedule file:', error);
        return interaction.editReply('There was an error reading the schedule data.');
      }
    } else {
      return interaction.editReply('No events are currently scheduled.');
    }
    
    // Find the event
    const event = scheduleData.find(e => e.id === eventId);
    
    if (!event) {
      return interaction.editReply('Could not find an event with that ID. Please check the ID and try again.');
    }
    
    // Create Discord timestamps for the event
    const timestamp = Math.floor(event.timestamp / 1000);
    const fullTimestamp = `<t:${timestamp}:F>`;  // Full date and time
    
    // Create embed
    const embed = new EmbedBuilder()
      .setColor(getEventColor(event.type))
      .setTitle(`👥 Attendance for ${event.type}`)
      .setDescription(`Event scheduled for ${fullTimestamp}`)
      .addFields(
        { name: 'Event Details', value: event.notes || 'No details provided' }
      )
      .setTimestamp()
      .setFooter({ text: `Event ID: ${event.id}` });
    
    // Check if there are attendees
    if (!event.attendees || event.attendees.length === 0) {
      embed.addFields({ name: 'Attendees', value: 'No one has signed up to attend this event yet.' });
    } else {
      // Get attendee information
      let attendeeList = '';
      
      for (let i = 0; i < event.attendees.length; i++) {
        const userId = event.attendees[i];
        attendeeList += `${i+1}. <@${userId}>\n`;
      }
      
      embed.addFields({ name: `Attendees (${event.attendees.length})`, value: attendeeList });
    }
    
    // Reply with attendance information
    return interaction.editReply({ embeds: [embed] });
  }
};

// Get a color for the embed based on event type
function getEventColor(eventType) {
  switch (eventType) {
    case 'Assault':
      return '#FF0000'; // Red
    case 'Patrol Response':
      return '#0099FF'; // Blue
    case 'Down with the Facility':
      return '#FF9900'; // Orange
    case 'Training':
      return '#33CC33'; // Green
    default:
      return '#6E6E6E'; // Gray
  }
}