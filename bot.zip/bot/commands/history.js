const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../utils/database');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('history')
    .setDescription('View a user\'s points history')
    .addUserOption(option => 
      option.setName('user')
        .setDescription('The user to check history for')
        .setRequired(true))
    .addIntegerOption(option => 
      option.setName('limit')
        .setDescription('Number of records to show (default: 5)')
        .setMinValue(1)
        .setMaxValue(10)),
  
  async execute(interaction) {
    // Check if user has the agent role or higher
    const agentRoleId = config.AGENT_ROLE_ID;
    const guildMember = interaction.member;
    
    // Check if user has the specific role or any higher role
    const hasRequiredPermission = guildMember.roles.cache.some(role => {
      return role.id === agentRoleId || (role.position > guildMember.guild.roles.cache.get(agentRoleId)?.position);
    });
    
    const user = interaction.options.getUser('user');
    
    // If not an agent or higher role, only allow viewing own history
    if (!hasRequiredPermission && user.id !== interaction.user.id) {
      return interaction.reply({
        content: `You can only view your own history unless you have the <@&${agentRoleId}> role or higher.`,
        ephemeral: true
      });
    }
    
    await interaction.deferReply();
    const limit = interaction.options.getInteger('limit') || 5;
    
    // Get the user's history from the database
    const history = db.getUserHistory(user.id);
    
    if (!history || history.length === 0) {
      return interaction.editReply(`${user.username} has no points history.`);
    }
    
    // Sort by timestamp (newest first) and limit the results
    const recentHistory = [...history]
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, limit);
    
    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle(`Points History for ${user.username}`)
      .setDescription(`Showing the ${recentHistory.length} most recent points transactions`)
      .setTimestamp();
    
    // Add each history entry as a field in the embed
    for (let i = 0; i < recentHistory.length; i++) {
      const entry = recentHistory[i];
      const pointsText = entry.points > 0 ? `+${entry.points}` : `${entry.points}`;
      const date = new Date(entry.timestamp).toLocaleString();
      
      // Try to fetch agent username
      let agentName = 'Unknown Agent';
      try {
        const agent = await interaction.client.users.fetch(entry.moderatorId);
        agentName = agent.username;
      } catch (error) {
        // If we can't fetch the agent (e.g., they left the server)
        agentName = `Unknown (${entry.moderatorId})`;
      }
      
      embed.addFields({
        name: `${date} • ${pointsText} points`,
        value: `**Reason:** ${entry.reason}\n**By:** ${agentName}`
      });
    }
    
    // Add the current total
    embed.addFields({
      name: 'Current Total',
      value: `${db.getUserPoints(user.id)} points`
    });
    
    return interaction.editReply({ embeds: [embed] });
  }
};