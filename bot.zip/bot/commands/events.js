const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('events')
    .setDescription('View scheduled events')
    .addStringOption(option =>
      option.setName('type')
        .setDescription('Filter events by type')
        .setRequired(false)
        .addChoices(
          { name: 'Assault', value: 'Assault' },
          { name: 'Patrol Response', value: 'Patrol Response' },
          { name: 'Down with the Facility', value: 'Down with the Facility' },
          { name: 'Training', value: 'Training' }
        )),
  
  async execute(interaction) {
    await interaction.deferReply();
    
    // Get event type filter if provided
    const eventTypeFilter = interaction.options.getString('type');
    
    // Load schedule data
    const scheduleFilePath = path.join(__dirname, '..', 'schedule.json');
    let scheduleData = [];
    
    if (fs.existsSync(scheduleFilePath)) {
      try {
        const fileContent = fs.readFileSync(scheduleFilePath, 'utf8');
        scheduleData = JSON.parse(fileContent);
      } catch (error) {
        console.error('Error reading schedule file:', error);
        return interaction.editReply('There was an error reading the schedule data.');
      }
    }
    
    // If no events exist
    if (scheduleData.length === 0) {
      return interaction.editReply('No events are currently scheduled.');
    }
    
    // Filter events by type if requested
    let filteredEvents = scheduleData;
    if (eventTypeFilter) {
      filteredEvents = scheduleData.filter(event => event.type === eventTypeFilter);
      
      if (filteredEvents.length === 0) {
        return interaction.editReply(`No ${eventTypeFilter} events are currently scheduled.`);
      }
    }
    
    // Ensure we have timestamp data for sorting and display
    filteredEvents.forEach(event => {
      // If we have a timestamp stored, use it directly
      if (event.timestamp) {
        event.dateObj = new Date(event.timestamp);
      } 
      // For backwards compatibility with older events
      else {
        // Parse MM/DD/YY format and time if available
        const [month, day, year] = event.date.split('/');
        
        if (event.time) {
          // Parse HH:MM AM/PM format
          const timePattern = /^(0?[1-9]|1[0-2]):([0-5][0-9])(?:\s)?(AM|PM|am|pm)$/;
          const timeMatch = event.time.match(timePattern);
          
          if (timeMatch) {
            let [hours, minutes] = [parseInt(timeMatch[1]), parseInt(timeMatch[2])];
            const isPM = timeMatch[3].toUpperCase() === 'PM';
            
            // Convert to 24-hour format if PM
            if (isPM && hours < 12) hours += 12;
            if (!isPM && hours === 12) hours = 0;
            
            event.dateObj = new Date(2000 + parseInt(year), parseInt(month) - 1, parseInt(day), hours, minutes);
          } else {
            event.dateObj = new Date(2000 + parseInt(year), parseInt(month) - 1, parseInt(day));
          }
        } else {
          event.dateObj = new Date(2000 + parseInt(year), parseInt(month) - 1, parseInt(day));
        }
        
        // Store the timestamp for future use
        event.timestamp = event.dateObj.getTime();
      }
    });
    
    // Sort events by date (closest first)
    filteredEvents.sort((a, b) => a.dateObj - b.dateObj);
    
    // Remove past events (older than current date)
    const currentDate = new Date();
    filteredEvents = filteredEvents.filter(event => event.dateObj >= currentDate);
    
    if (filteredEvents.length === 0) {
      return interaction.editReply(eventTypeFilter 
        ? `No upcoming ${eventTypeFilter} events are currently scheduled.` 
        : 'No upcoming events are currently scheduled.');
    }
    
    // Group events by month/year for better organization
    const eventsByMonth = {};
    filteredEvents.forEach(event => {
      const monthYear = `${event.dateObj.getMonth() + 1}/${event.dateObj.getFullYear()}`;
      if (!eventsByMonth[monthYear]) {
        eventsByMonth[monthYear] = [];
      }
      eventsByMonth[monthYear].push(event);
    });
    
    // Create embed
    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('📅 Scheduled Events')
      .setDescription(eventTypeFilter ? `Showing upcoming ${eventTypeFilter} events` : 'Showing all upcoming events')
      .setTimestamp();
    
    // Add events to embed by month
    for (const [monthYear, events] of Object.entries(eventsByMonth)) {
      let eventsText = '';
      
      // Get month name from the monthYear string
      const [month, year] = monthYear.split('/');
      const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                          'July', 'August', 'September', 'October', 'November', 'December'];
      const monthName = monthNames[parseInt(month) - 1];
      
      events.forEach(event => {
        // Add emoji based on event type
        let emoji = '🔷';
        if (event.type === 'Assault') emoji = '⚔️';
        if (event.type === 'Patrol Response') emoji = '🚨';
        if (event.type === 'Down with the Facility') emoji = '🏢';
        if (event.type === 'Training') emoji = '🎓';
        
        // Create Discord timestamps that will show in user's local time
        const unix = Math.floor(event.timestamp / 1000);
        const dateOnlyTimestamp = `<t:${unix}:D>`; // Date only (e.g., "June 1, 2023")
        const timeOnlyTimestamp = `<t:${unix}:t>`; // Time only (e.g., "4:30 PM")
        const shortTimestamp = `<t:${unix}:f>`;    // Short date and time (e.g., "June 1, 2023 4:30 PM")
        const relativeTime = `<t:${unix}:R>`;      // Relative time (e.g., "in 2 days")
        
        eventsText += `${emoji} **${event.type}**\n`;
        eventsText += `› Date: ${dateOnlyTimestamp}\n`;
        eventsText += `› Time: ${timeOnlyTimestamp}\n`;
        eventsText += `› ${relativeTime}\n`;
        eventsText += `› Notes: ${event.notes}\n`;
        
        // Add attendance information if available
        if (event.attendees && event.attendees.length > 0) {
          eventsText += `› Attendees: ${event.attendees.length}\n`;
        } else {
          eventsText += `› Attendees: 0\n`;
        }
        
        eventsText += `› ID: ${event.id}\n\n`;
      });
      
      embed.addFields({ name: `${monthName} ${year}`, value: eventsText });
    }
    
    // Create action rows with attendance buttons for each event
    const actionRows = [];
    let rowCount = 0;
    
    // Maximum of 5 action rows per message
    for (const monthYear in eventsByMonth) {
      if (rowCount >= 5) break;
      
      const events = eventsByMonth[monthYear];
      // Get only the first event from each month to stay within Discord's limits
      if (events.length > 0) {
        const event = events[0];
        
        // Create an attendance button for this event
        const attendButton = new ButtonBuilder()
          .setCustomId(`attend_${event.id}`)
          .setLabel(`Attend ${event.type}`)
          .setStyle(ButtonStyle.Success)
          .setEmoji('✅');
        
        // Add the button to an action row
        const row = new ActionRowBuilder().addComponents(attendButton);
        actionRows.push(row);
        rowCount++;
      }
    }
    
    // Send response with the buttons
    return interaction.editReply({ 
      embeds: [embed],
      components: actionRows 
    });
  }
};